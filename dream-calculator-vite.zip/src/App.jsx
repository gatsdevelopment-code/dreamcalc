import React from 'react'
import DreamCalculator from './DreamCalculator.jsx'

export default function App(){ 
  return <DreamCalculator /> 
}
